<footer class="text-center my-4">
		<b><p> All UsedCardboardBoxes.com gaylord totes and shipping boxes are USED unless explicitly stated otherwise.</p>
    <p>Available used gaylords totes and used shipping boxes SKUs may vary and are limited to stock on hand.</p>
    <p>Copyright 2023 Used Cardboard Boxes, Inc. </p>
    <p>For UsedCardboardBoxes.com customers of North America only.</p>
    </b>
	</footer>
</body>

</html>